# from django.contrib import admin
# from Comments.models import Comment
#
# admin.site.register(Comment)